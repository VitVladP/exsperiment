package main.java.com.ActionsByUser;


import java.util.Arrays;
import java.util.EnumMap;

class MyGenericService {
    enum SortBy {
        DESC, //по возрастанию
        ASC,
        RANDOM
    }

    static <T extends Number> void sortIntArray(T[] array, String method) {
        EnumMap<SortBy, MyGenericService.SortArray<T>> enumMapSort = new EnumMap<>(SortBy.class);
        enumMapSort.put(SortBy.DESC, MyGenericService::sortDESC);
        enumMapSort.put(SortBy.ASC, MyGenericService::sortASC);
        enumMapSort.put(SortBy.RANDOM, MyGenericService::sortRandom);

        enumMapSort.get(SortBy.valueOf(method)).sort(array);
    }

    interface SortArray <T extends Number>{
        void sort (T [] array);

    }

    private static <T extends Number> void sortDESC(T [] arr) {
        Arrays.sort(arr);
    }

    private static <T extends Number> void sortASC(T [] arr){
        sortDESC(arr);
        reverceArray(arr);
    }
    private static <T extends Number> void reverceArray(T [] arr){

        Arrays.stream(arr).forEach((it, index) -> changeElementsInArray(arr,index,index2));
    }
    private static <T extends Number> void sortRandom(T [] arr){

        for (int i = 0; i < arr.length; i++)
            changeElementsInArray(arr,i,(int) Math.random()*(arr.length ));

    }

    private static <T extends Number> void changeElementsInArray(T [] array, int index1, int index2){
        T temp;
        temp = array[index1];
        array[index1] = array[index2];
        array[index2]  = temp;
    }


}
