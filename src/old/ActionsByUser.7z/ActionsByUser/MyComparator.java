package main.java.com.ActionsByUser;

import java.util.*;

public class MyComparator {

    enum SortBy {
        FIRSTNAME,
        SECONDNAME,
        FIO,
        AMOUNT
    }

    /**
     * Выводит на экран остортированное дерево солгласно метода сортировки
     * FIRSTNAME - сортировак по имени
     * SECONDNAME - сортировка по фамилии
     * FIO - сортировка по имени и фамилии
     * AMOUNT - сортировка по полю оклад.
     * \
     *
     * @param treeSet
     * @param method
     */

    public static void compareData(TreeMap<String, Integer> treeSet, String method) {
        EnumMap<SortBy, SortStringByComparator> map = new EnumMap<>(SortBy.class);
        map.put(SortBy.FIRSTNAME, MyComparator::sortByFirstName);
        map.put(SortBy.FIO, MyComparator::sortByFIO);
        map.put(SortBy.SECONDNAME, MyComparator::sortBySecodName);
        map.put(SortBy.AMOUNT, MyComparator::sortByAmount);
        map.get(SortBy.valueOf(method)).compare(treeSet);
    }

    private static Comparator<Map.Entry<String, Integer>> getComparatorFIO() {
        return getComparatorFirstName().thenComparing(getComparatorSecondName());

    }

    private static Comparator<Map.Entry<String, Integer>> getComparatorSecondName() {
        return (Map.Entry<String, Integer> entry1, Map.Entry<String, Integer> entry2) -> {
            int i, j;
            String str1 = entry1.getKey();
            String str2 = entry2.getKey();
            i = str1.lastIndexOf(' ');
            j = str2.lastIndexOf(' ');
            return str1.substring(i).compareTo(str2.substring(j));

        };
    }

    private static Comparator<Map.Entry<String, Integer>> getComparatorAmount() {
        return (Map.Entry<String, Integer> entry1, Map.Entry<String, Integer> entry2) -> {
            Integer num1 = entry1.getValue();
            Integer num2 = entry2.getValue();
            return num1.compareTo(num2);
        };
    }

    private static Comparator<Map.Entry<String, Integer>> getComparatorFirstName() {
        return (Map.Entry<String, Integer> entry1, Map.Entry<String, Integer> entry2) -> {
            String str1 = entry1.getKey();
            String str2 = entry2.getKey();
            return str1.compareTo(str2);
        };
    }

    interface SortStringByComparator {
        void compare(TreeMap<String, Integer> set);
    }

    private static void sortByFirstName(TreeMap<String, Integer> set) {
        printResult(set, getComparatorFirstName());
    }

    private static void sortBySecodName(TreeMap<String, Integer> set) {
        printResult(set, getComparatorSecondName());
    }

    private static void sortByAmount(TreeMap<String, Integer> set) {
        printResult(set, getComparatorAmount());

    }

    private static void sortByFIO(TreeMap<String, Integer> set) {

        printResult(set, getComparatorFIO());
    }


    private static void printResult(TreeMap<String, Integer> tree, Comparator<Map.Entry<String, Integer>> comp) {
        tree.entrySet()
                .stream()
                .sorted(comp)
                .forEach(element -> System.out.printf("\"%s\":\"%d\"\n", element.getKey(), element.getValue()));
    }
}


