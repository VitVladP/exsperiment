package main.java.com.ActionsByUser;

import java.util.Arrays;
import java.util.TreeMap;

public class UserInterface {


    public static void main(String[] args) {

        int[] array ={2,4,6,9,1,3,5,7 };
        MyService.sortIntArray(array,"ASC");
        System.out.println(Arrays.toString(array));

        //Через Generic
        Double[] arrayDouble ={2.4,4.4,4.5,9.0,1.3,5.2,5.0,7.0 };
        MyGenericService.sortIntArray(arrayDouble,"ASC");
        System.out.println(Arrays.toString(arrayDouble));

        TreeMap <String,Integer> tree = new TreeMap<>();
        tree.put("test Bloch",8000);
        tree.put("vet Surfer",6000);
        tree.put("dude Soun",2000);
        tree.put("user Anderson",5000);
        tree.put("user Devil",3000);

        MyComparator.compareData(tree,"AMOUNT");
    }

}
