package main.java.com.ActionsByUser;

import java.util.*;

class MyService {

    enum SortBy {
        DESC, //по возрастанию
        ASC,
        RANDOM
    }
    private static void sortDESC(int[] arr) {
        Arrays.sort(arr);
    }

    static void sortIntArray(int[] array, String method) {
        EnumMap<SortBy, SortArray> enumMapSort = new EnumMap<>(SortBy.class);
        enumMapSort.put(SortBy.DESC, MyService::sortDESC);
        enumMapSort.put(SortBy.ASC, MyService::sortASC);
        enumMapSort.put(SortBy.RANDOM, MyService::sortRandom);
        enumMapSort.get(SortBy.valueOf(method)).sort(array);
    }

    interface SortArray {
        void sort (int[] array);
    }

    private static void sortASC(int[] arr){
        sortDESC(arr);
        reverceArray(arr);
    }

    private static void reverceArray(int [] arr){
        for (int i = 0; i < (arr.length)/2; i++) {
            changeElementsInArray(arr,i,arr.length - i - 1);
        }
    }

    private static void sortRandom(int [] arr){

        for (int i = 0; i < arr.length; i++) {
            changeElementsInArray(arr, i, (int) (Math.random() * (arr.length)));
        }
    }

    private static void changeElementsInArray(int[] array, int index1, int index2){
        int temp;
        temp = array[index1];
        array[index1] = array[index2];
        array[index2]  = temp;
    }

}

