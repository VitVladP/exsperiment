package com.transferMoney;

public class Card {
    private String cardNumber;
    private String banksBik;
    private int userId;

    public Card(String cardNumber, String banksBik, int userId) {
        this.cardNumber = cardNumber;
        this.banksBik = banksBik;
        this.userId = userId;
    }


    public String getBanksBik() {
        return banksBik;
    }


}
