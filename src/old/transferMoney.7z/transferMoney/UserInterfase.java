package com.transferMoney;

public class UserInterfase {
    public static void main(String[] args) {
        DataBase.createDemoDatabase();
        Operation test = new Operation( );

        test.transferMoney("01-01-01","01-01-02", Operation.TransferType.CARDTOCARD);
        test.transferMoney("03-01-01","02-01-02", Operation.TransferType.CARDTOCARD);
        test.transferMoney("02-02-01","03-02-02", Operation.TransferType.CARDTOBILL);
    }
}
