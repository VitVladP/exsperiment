package com.transferMoney;

import java.util.HashMap;
import java.util.HashSet;

public class Bank {
    private String bankName;
    private String bik;
    private HashSet<String> partnersBik = new HashSet<>();
    private HashMap<String,Double> cards = new HashMap<>(); //String = cards number Double = amount
    private HashMap<String,Double> bills = new HashMap<>(); //String = bill number Double = amount


    public Bank(String bankName, String bik) {
        this.bankName = bankName;
        this.bik = bik;
    }

    public void addCardToBank(String cardNumber, Double amount){
        cards.put(cardNumber,amount);
    }
    public void addBillToBank (String bill,Double ammount){
        bills.put(bill,ammount);
    }


    public void setPartnersBik(HashSet<String> partnersBik) {
        this.partnersBik = partnersBik;
    }

    @Override
    public boolean equals(Object obj){
        if (obj == null || getClass()!=obj.getClass()) return false;
        if (this == obj) return true;
        Bank bank = (Bank) obj;

        if (bankName != bank.bankName) return false;
        if (bik != bank.bik) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = bankName != null ? bankName.hashCode():0;
        result = 31*result + (bik != null ? bik.hashCode() : 0);
        return result;
    }
    @Override
    public String toString(){
        return String.format("{\"banrName\":\"%s\",\"bik\":\"%s\"}",
                bankName,bik);
    }

    public String isPartner (String bikPartner) {
        if (bik == bikPartner) return "OWN";
        if (partnersBik.contains(bikPartner)) return "PARTNER";
        return "OTHER";
    }

//    private <T extends Collection<E>> void printSet(T set){
//        for (E element:
//             set) {
//            System.out.println(element);
//        }
//    }
}


