package com.transferMoney;

public class Bill {
    private String billNumber;
    private String banksBik;
    private int userId;

    public Bill(String banksBik , String billNumber, int userId) {
        this.billNumber = billNumber;
        this.banksBik = banksBik;
        this.userId = userId;
    }



    public String getBanksBik() {
        return banksBik;
    }



}
