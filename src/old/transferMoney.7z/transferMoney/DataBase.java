package com.transferMoney;


import java.util.HashMap;
import java.util.HashSet;

public class DataBase {

    private static HashMap<String, Bank> banks = new HashMap<>(); //string = bik
    private static HashMap<Integer, UserAccount> accaunts = new HashMap<>(); // integer = userId
    private static HashMap<String, Card> cards = new HashMap<>(); // cardNumber
    private static HashMap<String, Bill> bills = new HashMap<>(); // cardNumber

    public static Bank getBankByBik(String bik) {
        return banks.get(bik);
    }

    public static Card getCardByNumber(String number) {

        return cards.get(number);
    }


    public static Bill getBillByNumber(String number) {
        return bills.get(number);
    }

    public static void addBank(String bankName, String bik, HashSet<String> partners) {
        Bank bank = new Bank(bankName, bik);
        bank.setPartnersBik(partners);
        banks.put(bik, bank);
    }

    public static void addCard(String bankBik, String number) {

        cards.put(number, new Card(number, bankBik, 1));
        banks.get(bankBik).addCardToBank(number, 10000d);
    }
    public static void addBill (String bankBik, String number) {

        bills.put(number, new Bill(bankBik, number, 1));
        banks.get(bankBik).addBillToBank(number, 10000d);
    }

    public static void createDemoDatabase() {
        HashSet<String> partners1 = new HashSet<>();
        partners1.add("02");
        partners1.add("03");
        HashSet<String> partners2 = new HashSet<>();
        partners2.add("01");
        HashSet<String> partners3 = new HashSet<>();
        partners3.add("02");
        partners3.add("01");

        addBank("Otp", "01", partners1);
        addBank("Open", "02", partners2);
        addBank("touch", "03", partners3);

        addCard("01", "01-01-01");
        addCard("01", "01-01-02");
        addCard("01", "01-01-03");
        addCard("02", "02-01-01");
        addCard("02", "02-01-02");
        addCard("02", "02-01-03");
        addCard("03", "03-01-01");
        addCard("03", "03-01-02");
        addCard("03", "03-01-03");


        addBill("01", "01-02-01");
        addBill("01", "01-02-02");
        addBill("02", "02-02-01");
        addBill("02", "02-02-02");
        addBill("03", "03-02-01");
        addBill("03", "03-02-02");
    }

}
