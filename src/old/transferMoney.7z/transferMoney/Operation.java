package com.transferMoney;

import java.util.EnumMap;

public class Operation {

    private TransferInfo transferInfo;

    enum TransferType {
        CARDTOCARD,
        CARDTOBILL,
        BILLTOCARD,
        BILLTOBILL
    }

    enum TransferPersents {

        PARTNER(5),
        OWN(0),
        OTHER(10);

        private final int amount;

        TransferPersents(int amount) {
            this.amount = amount;
        }

        public int getAmount() {
            return amount;
        }
    }

    public void transferMoney(String from, String to, TransferType type){
        transferInfo = new TransferInfo(from, to, type);
        EnumMap<TransferType, TransferOperation> operations = new EnumMap<>(TransferType.class);
        operations.put(TransferType.CARDTOCARD, (transferInfo) -> cardToCardTransfer());
        operations.put(TransferType.CARDTOBILL, (transferInfo) -> cardToBillTransfer());
        operations.put(TransferType.BILLTOCARD, (transferInfo) -> billToCardTransfer());
        operations.put(TransferType.CARDTOBILL, (transferInfo) -> billToBillTransfer());

        operations.get(transferInfo.getType()).transfer(transferInfo);
    }

    interface TransferOperation {
        void transfer(TransferInfo transferInfo);
    }

    /*
    * Не представляю как  можно отрефакторить этот кусок
    * >>>>>>>>>>
    * */
    private void cardToBillTransfer() {

        printComition(TransferPersents.valueOf(getPartnerStatusC2B()).getAmount());
    }

    private void cardToCardTransfer() {
        printComition(TransferPersents.valueOf(getPartnerStatusC2C()).getAmount());
    }

    private void billToBillTransfer() {

        printComition(TransferPersents.valueOf(getPartnerStatusB2B()).getAmount());
    }

    private void billToCardTransfer() {

        printComition(TransferPersents.valueOf(getPartnerStatusB2C()).getAmount());
    }

    private void printComition(int amount) {
        System.out.println("Комиссия за перевод: " + amount + "%");
    }

    private String getPartnerStatusC2C() {

        return DataBase
                .getBankByBik(DataBase.getCardByNumber(transferInfo.getNumberFrom()).getBanksBik())
                .isPartner(DataBase.getCardByNumber(transferInfo.getNumberTo()).getBanksBik());
    }

    private String getPartnerStatusC2B() {

        return DataBase
                .getBankByBik(DataBase.getCardByNumber(transferInfo.getNumberFrom()).getBanksBik())
                .isPartner(DataBase.getBillByNumber(transferInfo.getNumberTo()).getBanksBik());
    }

    private String getPartnerStatusB2C() {

        return DataBase
                .getBankByBik(DataBase.getBillByNumber(transferInfo.getNumberFrom()).getBanksBik())
                .isPartner(DataBase.getCardByNumber(transferInfo.getNumberTo()).getBanksBik());
    }

    private String getPartnerStatusB2B() {

        return DataBase
                .getBankByBik(DataBase.getBillByNumber(transferInfo.getNumberFrom()).getBanksBik())
                .isPartner(DataBase.getBillByNumber(transferInfo.getNumberTo()).getBanksBik());
    }
/*
*<<<<<<<<<<<<<
* */


    class TransferInfo {
        private String numberFrom;
        private String numberTo;
        private TransferType type;


        public TransferInfo(String numberFrom, String numberTo, TransferType type) {
            this.numberFrom = numberFrom;
            this.numberTo = numberTo;
            this.type = type;
        }

        public String getNumberFrom() {
            return numberFrom;
        }

        public String getNumberTo() {
            return numberTo;
        }

        public TransferType getType() {
            return type;
        }
    }


}
