package com.transferMoney;

public class UserAccount {
    private static int counter = 0;
    private int userId;
    private String userName;
    private String cardNumber;
    private String billNumber;

    public UserAccount(String userName, String bankBik, String cardNumber, String billNumber, double amount) {

        this.userName = userName;
        this.cardNumber = cardNumber;
        this.billNumber = billNumber;
        this.userId = counter++;
    }


    @Override
    public boolean equals(Object obj){
    if (obj == null||getClass() != obj.getClass()) return false;
    if (this == obj) return true;

    UserAccount account = (UserAccount) obj;
    if (userName != account.userName) return false;
    if (userId != account.userId) return false;
    if (cardNumber != account.cardNumber) return false;
    if (billNumber != account.billNumber) return false;
    return true;
    }

    @Override
    public int hashCode(){
    int result = userName != null ? userName.hashCode():0;
    result = 31*result + (cardNumber!=null ? cardNumber.hashCode():0);
    result = 31*result + userId;
    result = 31*result + (billNumber != null ? billNumber.hashCode():0);
        return result;
    }

    @Override
    public String toString(){
        return String.format("{\"userId\":\"%d\",\"userName\":\"%s\",\"cardNumber\":\"%s\",\"billNumber\":\"%s\"",
                userId,userName,cardNumber,billNumber); //
    }
}
