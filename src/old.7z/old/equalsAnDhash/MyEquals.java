package com.equalsAnDhash;

public class MyEquals extends TestEquals{
    int persent;

    public MyEquals(final String name,final int salary,final int persent) {
        super(name, salary);
        this.persent = persent;
    }

}
