package enumTest;

public class Main {
    public static void main(String[] args) {
//        EnumTest.CREDIT.doSomething();
//        EnumTest.DEBIT.doSomething();
//        EnumTest.TEMP.doSomething();

        MyActions.doSomething("DEBIT");

    }
}
